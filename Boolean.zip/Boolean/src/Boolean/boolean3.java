package Boolean;

import java.util.Scanner;

public class boolean3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("A=");
        int A = sc.nextInt();

        System.out.println(A % 2 == 0);

    }
}
