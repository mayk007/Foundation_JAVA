package Loop.src.While;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class while26 {
    public static void main(String[] args) {

    }
}
