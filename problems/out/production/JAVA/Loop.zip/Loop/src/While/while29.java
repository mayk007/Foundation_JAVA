package Loop.src.While;

import java.util.Scanner;

public class while29 {

}
